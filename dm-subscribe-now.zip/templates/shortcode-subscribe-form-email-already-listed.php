<form id="subscribenow" method="GET" action="<?=site_url()?>">
  <h3>Email already confirmed</h3>
  <p>Your email is already included on our mailing list.</p>
  <button class="btn btn-success" type="submit">Go to Homepage</button>
</form>
