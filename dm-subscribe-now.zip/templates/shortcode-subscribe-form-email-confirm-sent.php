<form id="subscribenow" method="GET" action="<?php echo esc_attr( get_option('subscribenow_landing_page') ); ?>">
    <h3>Thank you for choosing Divestmedia.com</h3>
    <p>Please check your email to confirm your subscription</p>
    <button class="btn btn-success" type="submit">Go back</button>
</form>
