<form id="subscribenow" method="GET" action="<?=site_url()?>">
    <h3>Thank you for choosing Divestmedia.com</h3>
    <p>Subscription Complete. You will now start receiving newsletters</p>
    <button class="btn btn-success" type="submit">Back to home</button>
</form>
